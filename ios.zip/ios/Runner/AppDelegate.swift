import UIKit
import Flutter
import FirebaseCore
import FirebaseMessaging
@main
@objc class AppDelegate: FlutterAppDelegate {
  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
    GeneratedPluginRegistrant.register(with: self);
    FirebaseApp.configure();

     // CRITICAL: Set Firebase messaging delegate
//         [FIRMessaging messaging].delegate = self;
//         NSLog(@"🍎 Firebase messaging delegate set");
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }
}
