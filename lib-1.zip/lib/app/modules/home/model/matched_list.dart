class MatchedUser {
  final String uid;
  final String name;
  final String image;
  final double matchPercent;

  MatchedUser({
    required this.uid,
    required this.name,
    required this.image ,
    required this.matchPercent,
  });
}
